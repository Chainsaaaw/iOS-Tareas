import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    @IBOutlet weak var alphaSlider: UISlider!
    
    @IBOutlet weak var redLabel: UILabel!
    @IBOutlet weak var greenLabel: UILabel!
    @IBOutlet weak var blueLabel: UILabel!
    @IBOutlet weak var alphaLabel: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Configurar los sliders
        redSlider.value = 1.0
        greenSlider.value = 1.0
        blueSlider.value = 1.0
        alphaSlider.value = 1.0
        
        // Llamar a la función para actualizar el color de fondo de la imagen
        updateBackgroundColor()
    }
    
    @IBAction func sliderChanged(_ sender: UISlider) {
        // Actualizar el valor de los labels según el valor de los sliders
        redLabel.text = String( redSlider.value)
        greenLabel.text = String(greenSlider.value)
        blueLabel.text = String(blueSlider.value)
        alphaLabel.text = String(alphaSlider.value)
        
        // Llamar a la función para actualizar el color de fondo de la imagen
        updateBackgroundColor()
    }
    
    func updateBackgroundColor() {
        // Obtener los valores de los sliders
        let red = CGFloat(redSlider.value)
        let green = CGFloat(greenSlider.value)
        let blue = CGFloat(blueSlider.value)
        let alpha = CGFloat(alphaSlider.value)
        
        // Crear un color con los valores obtenidos
        let color = UIColor(red: red, green: green, blue: blue, alpha: alpha)
        
        // Actualizar el fondo de la imagen con el color creado
        imageView.backgroundColor = color
    }
}
