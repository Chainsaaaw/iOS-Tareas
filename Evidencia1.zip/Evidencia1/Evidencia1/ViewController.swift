import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var wordLabel: UILabel!
    @IBOutlet weak var incorrectAttemptsLabel: UIImageView!
    @IBOutlet weak var treeImageView: UIImageView!
    
    var wordToGuess = "SWIFT"
    var guessedLetters = Set<Character>()
    var incorrectAttempts = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    
    func updateUI() {
        var printedWord = ""
        for letter in wordToGuess {
            if guessedLetters.contains(letter) {
                printedWord.append(letter)
            } else {
                printedWord.append("_")
            }
            printedWord.append(" ")
        }
        wordLabel.text = printedWord
        incorrectAttemptsLabel.text = "Intentos incorrectos: \(incorrectAttempts)"
        treeImageView.image = UIImage(named: "tree\(incorrectAttempts)")
    }
    
    @IBAction func letterButtonTapped(_ sender: UIButton) {
        guard let letter = sender.titleLabel?.text?.uppercased().first else {
            return
        }
        
        if guessedLetters.contains(letter) {
            showAlert(message: "¡Ya has intentado esta letra!")
            return
        }
        
        guessedLetters.insert(letter)
        if !wordToGuess.contains(letter) {
            incorrectAttempts += 1
        }
        
        if wordToGuess.allSatisfy({ guessedLetters.contains($0) }) {
            showAlert(message: "¡Felicidades! ¡Has adivinado la palabra!")
        } else if incorrectAttempts >= 7 {
            showAlert(message: "¡Oh no! ¡Te has quedado sin intentos!")
        }
        
        updateUI()
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
